import React, { useEffect, useState } from 'react';
import { Link, useParams, useNavigate } from 'react-router-dom';
import { ChevronRight, Calendar, Plus, Trash2, AlertCircle, Save, Info } from 'lucide-react';
import { useElectionStore } from '../../stores/electionStore';
import { Position } from '../../types';

const EditElection: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  
  const { 
    elections, 
    loading, 
    error, 
    getElections, 
    updateElection, 
    addPosition,
    updatePosition,
    deletePosition
  } = useElectionStore();
  
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [positions, setPositions] = useState<Position[]>([]);
  const [validationErrors, setValidationErrors] = useState<Record<string, string>>({});
  const [isSaving, setIsSaving] = useState(false);
  
  useEffect(() => {
    getElections();
  }, [getElections]);
  
  useEffect(() => {
    if (elections.length > 0 && id) {
      const election = elections.find(e => e.id === id);
      if (election) {
        setTitle(election.title);
        setDescription(election.description);
        setStartDate(new Date(election.startDate).toISOString().slice(0, 16));
        setEndDate(new Date(election.endDate).toISOString().slice(0, 16));
        setPositions(election.positions);
      }
    }
  }, [elections, id]);
  
  const handleAddPosition = () => {
    setPositions([
      ...positions,
      {
        id: `new-${Date.now()}`, // Temporary ID for new positions
        title: '',
        description: '',
        maxSelections: 1,
        candidates: [],
      },
    ]);
  };
  
  const handleUpdatePosition = (index: number, field: string, value: string | number) => {
    const updatedPositions = [...positions];
    updatedPositions[index] = {
      ...updatedPositions[index],
      [field]: value,
    };
    setPositions(updatedPositions);
  };
  
  const handleRemovePosition = (index: number) => {
    const updatedPositions = [...positions];
    updatedPositions.splice(index, 1);
    setPositions(updatedPositions);
  };
  
  const validateForm = (): boolean => {
    const errors: Record<string, string> = {};
    
    if (!title.trim()) {
      errors.title = 'Election title is required';
    }
    
    if (!description.trim()) {
      errors.description = 'Description is required';
    }
    
    if (!startDate) {
      errors.startDate = 'Start date is required';
    }
    
    if (!endDate) {
      errors.endDate = 'End date is required';
    }
    
    if (startDate && endDate && new Date(startDate) >= new Date(endDate)) {
      errors.endDate = 'End date must be after start date';
    }
    
    if (positions.length === 0) {
      errors.positions = 'At least one position is required';
    } else {
      positions.forEach((position, index) => {
        if (!position.title.trim()) {
          errors[`position_${index}_title`] = 'Position title is required';
        }
        
        if (!position.description.trim()) {
          errors[`position_${index}_description`] = 'Position description is required';
        }
        
        if (!position.maxSelections || position.maxSelections < 1) {
          errors[`position_${index}_maxSelections`] = 'Maximum selections must be at least 1';
        }
      });
    }
    
    setValidationErrors(errors);
    return Object.keys(errors).length === 0;
  };
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!id || !validateForm()) {
      return;
    }
    
    setIsSaving(true);
    
    try {
      // Determine status based on dates
      const now = new Date();
      const start = new Date(startDate);
      const end = new Date(endDate);
      
      let status: 'upcoming' | 'active' | 'completed';
      if (now < start) {
        status = 'upcoming';
      } else if (now >= start && now <= end) {
        status = 'active';
      } else {
        status = 'completed';
      }
      
      // First, update the basic election details
      await updateElection(id, {
        title,
        description,
        startDate,
        endDate,
        status,
      });
      
      // Get the current election to compare with updated positions
      const currentElection = elections.find(e => e.id === id);
      if (!currentElection) throw new Error('Election not found');
      
      // Handle position changes
      const currentPositionIds = currentElection.positions.map(p => p.id);
      const updatedPositionIds = positions.map(p => p.id);
      
      // Process each position
      for (const position of positions) {
        if (position.id.startsWith('new-')) {
          // New position - add it
          await addPosition(id, {
            title: position.title,
            description: position.description,
            maxSelections: position.maxSelections,
          });
        } else if (currentPositionIds.includes(position.id)) {
          // Existing position - update it
          const currentPosition = currentElection.positions.find(p => p.id === position.id);
          if (currentPosition && (
            currentPosition.title !== position.title ||
            currentPosition.description !== position.description ||
            currentPosition.maxSelections !== position.maxSelections
          )) {
            await updatePosition(id, position.id, {
              title: position.title,
              description: position.description,
              maxSelections: position.maxSelections,
            });
          }
        }
      }
      
      // Delete removed positions
      for (const posId of currentPositionIds) {
        if (!updatedPositionIds.includes(posId)) {
          await deletePosition(id, posId);
        }
      }
      
      navigate('/admin/elections');
    } catch (error) {
      console.error('Error updating election:', error);
    } finally {
      setIsSaving(false);
    }
  };
  
  if (loading && !title) {
    return (
      <div className="flex justify-center items-center h-64">
        <svg className="animate-spin h-10 w-10 text-primary-600\" xmlns="http://www.w3.org/2000/svg\" fill="none\" viewBox="0 0 24 24">
          <circle className="opacity-25\" cx="12\" cy="12\" r="10\" stroke="currentColor\" strokeWidth="4"></circle>
          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
        </svg>
      </div>
    );
  }
  
  const election = elections.find(e => e.id === id);
  
  if (!election && !loading) {
    return (
      <div className="rounded-md bg-red-50 p-4">
        <div className="flex">
          <div className="flex-shrink-0">
            <AlertCircle className="h-5 w-5 text-red-400" />
          </div>
          <div className="ml-3">
            <h3 className="text-sm font-medium text-red-800">Election not found</h3>
            <div className="mt-4">
              <Link to="/admin/elections" className="btn-primary">
                Back to Elections
              </Link>
            </div>
          </div>
        </div>
      </div>
    );
  }
  
  return (
    <div>
      <div className="mb-1">
        <Link to="/admin/elections" className="text-sm text-primary-600 hover:text-primary-800 flex items-center">
          <ChevronRight className="h-4 w-4 mr-1 transform rotate-180" />
          Back to Elections
        </Link>
      </div>
      
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Edit Election</h1>
        <p className="mt-1 text-sm text-gray-600">
          Update election details, positions, and voting information.
        </p>
      </div>
      
      {error && (
        <div className="rounded-md bg-red-50 p-4 mb-6">
          <div className="flex">
            <div className="flex-shrink-0">
              <AlertCircle className="h-5 w-5 text-red-400" />
            </div>
            <div className="ml-3">
              <h3 className="text-sm font-medium text-red-800">Error updating election</h3>
              <p className="mt-2 text-sm text-red-700">{error}</p>
            </div>
          </div>
        </div>
      )}
      
      <form onSubmit={handleSubmit}>
        <div className="bg-white shadow-card rounded-lg p-6 mb-6">
          <h2 className="text-lg font-medium text-gray-900 mb-4">Election Details</h2>
          
          <div className="space-y-4">
            <div>
              <label htmlFor="title" className="label">
                Election Title
              </label>
              <input
                type="text"
                id="title"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className={`input ${validationErrors.title ? 'border-red-500' : ''}`}
                placeholder="e.g. Student Council Election 2025"
              />
              {validationErrors.title && (
                <p className="mt-1 text-sm text-red-600">{validationErrors.title}</p>
              )}
            </div>
            
            <div>
              <label htmlFor="description" className="label">
                Description
              </label>
              <textarea
                id="description"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                rows={3}
                className={`input ${validationErrors.description ? 'border-red-500' : ''}`}
                placeholder="Provide a description of the election"
              />
              {validationErrors.description && (
                <p className="mt-1 text-sm text-red-600">{validationErrors.description}</p>
              )}
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label htmlFor="startDate" className="label">
                  Start Date and Time
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Calendar className="h-5 w-5 text-gray-400" />
                  </div>
                  <input
                    type="datetime-local"
                    id="startDate"
                    value={startDate}
                    onChange={(e) => setStartDate(e.target.value)}
                    className={`input pl-10 ${validationErrors.startDate ? 'border-red-500' : ''}`}
                  />
                </div>
                {validationErrors.startDate && (
                  <p className="mt-1 text-sm text-red-600">{validationErrors.startDate}</p>
                )}
              </div>
              
              <div>
                <label htmlFor="endDate" className="label">
                  End Date and Time
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Calendar className="h-5 w-5 text-gray-400" />
                  </div>
                  <input
                    type="datetime-local"
                    id="endDate"
                    value={endDate}
                    onChange={(e) => setEndDate(e.target.value)}
                    className={`input pl-10 ${validationErrors.endDate ? 'border-red-500' : ''}`}
                  />
                </div>
                {validationErrors.endDate && (
                  <p className="mt-1 text-sm text-red-600">{validationErrors.endDate}</p>
                )}
              </div>
            </div>
          </div>
        </div>
        
        <div className="bg-white shadow-card rounded-lg p-6 mb-6">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-lg font-medium text-gray-900">Positions</h2>
            <button
              type="button"
              onClick={handleAddPosition}
              className="btn-secondary flex items-center"
            >
              <Plus className="h-4 w-4 mr-1" />
              Add Position
            </button>
          </div>
          
          {validationErrors.positions && (
            <p className="mb-4 text-sm text-red-600">{validationErrors.positions}</p>
          )}
          
          {positions.length === 0 ? (
            <div className="text-center py-6 bg-gray-50 rounded-lg">
              <p className="text-gray-500">No positions added yet. Click "Add Position" to get started.</p>
            </div>
          ) : (
            <div className="space-y-6">
              {positions.map((position, index) => {
                const hasVotes = position.candidates.some(c => c.votes > 0);
                return (
                  <div key={position.id} className="border border-gray-200 rounded-lg p-4">
                    <div className="flex justify-between items-center mb-4">
                      <h3 className="text-md font-medium text-gray-900">
                        {position.title || `Position ${index + 1}`}
                      </h3>
                      {hasVotes ? (
                        <div className="flex items-center text-sm text-amber-600">
                          <Info className="h-4 w-4 mr-1" />
                          <span>Has votes</span>
                        </div>
                      ) : (
                        <button
                          type="button"
                          onClick={() => handleRemovePosition(index)}
                          className="text-red-600 hover:text-red-800"
                        >
                          <Trash2 className="h-5 w-5" />
                        </button>
                      )}
                    </div>
                    
                    <div className="space-y-4">
                      <div>
                        <label htmlFor={`position-${index}-title`} className="label">
                          Position Title
                        </label>
                        <input
                          type="text"
                          id={`position-${index}-title`}
                          value={position.title}
                          onChange={(e) => handleUpdatePosition(index, 'title', e.target.value)}
                          className={`input ${validationErrors[`position_${index}_title`] ? 'border-red-500' : ''}`}
                          placeholder="e.g. President, Treasurer, etc."
                        />
                        {validationErrors[`position_${index}_title`] && (
                          <p className="mt-1 text-sm text-red-600">{validationErrors[`position_${index}_title`]}</p>
                        )}
                      </div>
                      
                      <div>
                        <label htmlFor={`position-${index}-description`} className="label">
                          Description
                        </label>
                        <textarea
                          id={`position-${index}-description`}
                          value={position.description}
                          onChange={(e) => handleUpdatePosition(index, 'description', e.target.value)}
                          rows={2}
                          className={`input ${validationErrors[`position_${index}_description`] ? 'border-red-500' : ''}`}
                          placeholder="Describe the responsibilities of this position"
                        />
                        {validationErrors[`position_${index}_description`] && (
                          <p className="mt-1 text-sm text-red-600">{validationErrors[`position_${index}_description`]}</p>
                        )}
                      </div>
                      
                      <div>
                        <label htmlFor={`position-${index}-maxSelections`} className="label">
                          Maximum Number of Selections
                        </label>
                        <input
                          type="number"
                          id={`position-${index}-maxSelections`}
                          value={position.maxSelections}
                          onChange={(e) => handleUpdatePosition(index, 'maxSelections', parseInt(e.target.value))}
                          min="1"
                          className={`input ${validationErrors[`position_${index}_maxSelections`] ? 'border-red-500' : ''}`}
                          placeholder="1"
                          disabled={hasVotes}
                        />
                        <p className="mt-1 text-xs text-gray-500">
                          How many candidates a voter can select for this position (e.g., 1 for single selection, 2+ for multiple selections)
                        </p>
                        {hasVotes && (
                          <p className="mt-1 text-xs text-amber-600">
                            This cannot be changed because votes have already been cast
                          </p>
                        )}
                        {validationErrors[`position_${index}_maxSelections`] && (
                          <p className="mt-1 text-sm text-red-600">{validationErrors[`position_${index}_maxSelections`]}</p>
                        )}
                      </div>
                      
                      <div>
                        <div className="flex justify-between items-center">
                          <label className="label">Candidates</label>
                          <Link 
                            to={`/admin/candidates?election=${id}&position=${position.id}`}
                            className="text-sm text-primary-600 hover:text-primary-800"
                          >
                            Manage Candidates
                          </Link>
                        </div>
                        <div className="mt-1 p-3 bg-gray-50 rounded-md">
                          {position.candidates.length > 0 ? (
                            <ul className="space-y-2">
                              {position.candidates.map(candidate => (
                                <li key={candidate.id} className="text-sm">
                                  • {candidate.name} ({candidate.department}, Year {candidate.year})
                                  {candidate.votes > 0 && (
                                    <span className="ml-2 text-xs text-amber-600">
                                      {candidate.votes} votes
                                    </span>
                                  )}
                                </li>
                              ))}
                            </ul>
                          ) : (
                            <p className="text-sm text-gray-500">No candidates yet</p>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
          
          {positions.length > 0 && (
            <div className="mt-4">
              <button
                type="button"
                onClick={handleAddPosition}
                className="text-primary-600 font-medium flex items-center hover:text-primary-800"
              >
                <Plus className="h-4 w-4 mr-1" />
                Add Another Position
              </button>
            </div>
          )}
        </div>
        
        <div className="flex justify-end space-x-4">
          <Link 
            to="/admin/elections" 
            className="btn-secondary"
          >
            Cancel
          </Link>
          <button
            type="submit"
            className="btn-primary flex items-center"
            disabled={isSaving}
          >
            {isSaving ? (
              <>
                <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white\" xmlns="http://www.w3.org/2000/svg\" fill="none\" viewBox="0 0 24 24">
                  <circle className="opacity-25\" cx="12\" cy="12\" r="10\" stroke="currentColor\" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                Saving...
              </>
            ) : (
              <>
                <Save className="h-5 w-5 mr-1" />
                Save Changes
              </>
            )}
          </button>
        </div>
      </form>
    </div>
  );
};

export default EditElection;