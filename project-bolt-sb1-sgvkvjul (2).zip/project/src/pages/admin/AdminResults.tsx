import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Search, Calendar, BarChart4, AlertCircle, Eye, Download, Trophy } from 'lucide-react';
import { useElectionStore } from '../../stores/electionStore';
import { Election, ElectionResult, PositionResult } from '../../types';

const AdminResults: React.FC = () => {
  const { elections, loading, error, getElections } = useElectionStore();
  
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [electionResults, setElectionResults] = useState<Record<string, ElectionResult>>({});
  
  useEffect(() => {
    getElections();
  }, [getElections]);
  
  useEffect(() => {
    // Calculate results for all elections
    const results: Record<string, ElectionResult> = {};
    
    elections.forEach(election => {
      const positionResults: PositionResult[] = election.positions.map(position => {
        const totalVotes = position.candidates.reduce((sum, candidate) => sum + candidate.votes, 0);
        
        const candidateResults = position.candidates
          .map(candidate => ({
            candidateId: candidate.id,
            candidateName: candidate.name,
            votes: candidate.votes,
            percentage: totalVotes > 0 ? (candidate.votes / totalVotes) * 100 : 0,
          }))
          .sort((a, b) => b.votes - a.votes);
        
        return {
          positionId: position.id,
          positionTitle: position.title,
          candidates: candidateResults,
          totalVotes,
        };
      });
      
      const totalVotes = positionResults.reduce((sum, position) => sum + position.totalVotes, 0);
      
      // Calculate voter turnout based on number of students
      // In a real app, you'd get the total number of eligible voters
      // For simplicity, we're just using 100 as the total student count
      const totalStudents = 100;
      const voterTurnout = totalStudents > 0 ? (totalVotes / (totalStudents * election.positions.length)) * 100 : 0;
      
      results[election.id] = {
        electionId: election.id,
        positions: positionResults,
        totalVotes,
        voterTurnout: Math.min(voterTurnout, 100), // Cap at 100%
      };
    });
    
    setElectionResults(results);
  }, [elections]);
  
  const formatDate = (dateString: string): string => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    }).format(date);
  };
  
  // Filter elections based on search query and status filter
  const filteredElections = elections
    .filter(election => 
      election.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      election.description.toLowerCase().includes(searchQuery.toLowerCase())
    )
    .filter(election => 
      statusFilter === 'all' || election.status === statusFilter
    );
  
  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <svg className="animate-spin h-10 w-10 text-primary-600\" xmlns="http://www.w3.org/2000/svg\" fill="none\" viewBox="0 0 24 24">
          <circle className="opacity-25\" cx="12\" cy="12\" r="10\" stroke="currentColor\" strokeWidth="4"></circle>
          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
        </svg>
      </div>
    );
  }
  
  const exportCsv = (election: Election) => {
    const result = electionResults[election.id];
    if (!result) return;
    
    let csvContent = 'data:text/csv;charset=utf-8,';
    
    // Add header
    csvContent += 'Election:,' + election.title + '\n';
    csvContent += 'Date:,' + formatDate(election.startDate) + ' to ' + formatDate(election.endDate) + '\n';
    csvContent += 'Status:,' + election.status + '\n';
    csvContent += 'Total Votes:,' + result.totalVotes + '\n';
    csvContent += 'Voter Turnout:,' + result.voterTurnout.toFixed(1) + '%\n\n';
    
    // Add position results
    result.positions.forEach(position => {
      csvContent += position.positionTitle + '\n';
      csvContent += 'Candidate,Votes,Percentage\n';
      
      position.candidates.forEach(candidate => {
        csvContent += `${candidate.candidateName},${candidate.votes},${candidate.percentage.toFixed(1)}%\n`;
      });
      
      csvContent += '\n';
    });
    
    // Create download link
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `${election.title.replace(/\s+/g, '_')}_results.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };
  
  return (
    <div>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Election Results</h1>
        <p className="mt-1 text-sm text-gray-600">
          View and analyze voting results for all elections.
        </p>
      </div>
      
      {error && (
        <div className="rounded-md bg-red-50 p-4 mb-6">
          <div className="flex">
            <div className="flex-shrink-0">
              <AlertCircle className="h-5 w-5 text-red-400" />
            </div>
            <div className="ml-3">
              <h3 className="text-sm font-medium text-red-800">Error loading election results</h3>
              <p className="mt-2 text-sm text-red-700">{error}</p>
            </div>
          </div>
        </div>
      )}
      
      {/* Search and Filter */}
      <div className="bg-white shadow-card rounded-lg p-6 mb-6">
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div className="sm:col-span-2">
            <label htmlFor="search" className="label">
              Search Elections
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Search className="h-5 w-5 text-gray-400" />
              </div>
              <input
                type="text"
                id="search"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="input pl-10"
                placeholder="Search by title or description..."
              />
            </div>
          </div>
          
          <div>
            <label htmlFor="statusFilter" className="label">
              Status
            </label>
            <select
              id="statusFilter"
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="input"
            >
              <option value="all">All Statuses</option>
              <option value="active">Active</option>
              <option value="upcoming">Upcoming</option>
              <option value="completed">Completed</option>
            </select>
          </div>
        </div>
      </div>
      
      {/* Elections Results List */}
      {filteredElections.length > 0 ? (
        <div className="space-y-6">
          {filteredElections.map(election => {
            const result = electionResults[election.id];
            if (!result) return null;
            
            return (
              <div key={election.id} className="bg-white shadow-card rounded-lg overflow-hidden">
                <div className="px-6 py-4 border-b border-gray-200">
                  <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
                    <div>
                      <h2 className="text-lg font-medium text-gray-900">{election.title}</h2>
                      <div className="mt-1 flex items-center text-sm text-gray-500">
                        <Calendar className="h-4 w-4 mr-1" />
                        <span>{formatDate(election.startDate)} to {formatDate(election.endDate)}</span>
                        <span className="mx-2">•</span>
                        <span className={`${
                          election.status === 'completed' 
                            ? 'text-gray-600' 
                            : election.status === 'active' 
                              ? 'text-green-600' 
                              : 'text-blue-600'
                        }`}>
                          {election.status.charAt(0).toUpperCase() + election.status.slice(1)}
                        </span>
                      </div>
                    </div>
                    <div className="mt-3 sm:mt-0 flex space-x-2">
                      <Link
                        to={`/results/${election.id}`}
                        className="btn-secondary flex items-center"
                      >
                        <Eye className="h-4 w-4 mr-1" />
                        View Details
                      </Link>
                      <button
                        type="button"
                        onClick={() => exportCsv(election)}
                        className="btn-primary flex items-center"
                      >
                        <Download className="h-4 w-4 mr-1" />
                        Export
                      </button>
                    </div>
                  </div>
                </div>
                
                <div className="px-6 py-4">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                    <div className="bg-gray-50 rounded-lg p-4">
                      <div className="flex items-center">
                        <BarChart4 className="h-5 w-5 text-primary-600 mr-2" />
                        <div>
                          <p className="text-xs text-gray-500">Total Votes</p>
                          <p className="text-lg font-semibold">{result.totalVotes}</p>
                        </div>
                      </div>
                    </div>
                    
                    <div className="bg-gray-50 rounded-lg p-4">
                      <div className="flex items-center">
                        <BarChart4 className="h-5 w-5 text-primary-600 mr-2" />
                        <div>
                          <p className="text-xs text-gray-500">Voter Turnout</p>
                          <p className="text-lg font-semibold">{result.voterTurnout.toFixed(1)}%</p>
                        </div>
                      </div>
                    </div>
                    
                    <div className="bg-gray-50 rounded-lg p-4">
                      <div className="flex items-center">
                        <Trophy className="h-5 w-5 text-primary-600 mr-2" />
                        <div>
                          <p className="text-xs text-gray-500">Positions</p>
                          <p className="text-lg font-semibold">{election.positions.length}</p>
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  {result.positions.length > 0 && (
                    <div>
                      <h3 className="text-sm font-medium text-gray-700 mb-2">Top Results by Position:</h3>
                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                        {result.positions.map(position => {
                          const winner = position.candidates[0];
                          return (
                            <div key={position.positionId} className="border border-gray-200 rounded-lg p-3">
                              <p className="text-sm font-medium text-gray-800">{position.positionTitle}</p>
                              {winner ? (
                                <div className="mt-2 flex items-center">
                                  <Trophy className="h-4 w-4 text-amber-500 mr-1" />
                                  <p className="text-sm">
                                    {winner.candidateName} - {winner.votes} votes
                                    {position.totalVotes > 0 && (
                                      <span className="text-xs text-gray-500 ml-1">
                                        ({winner.percentage.toFixed(1)}%)
                                      </span>
                                    )}
                                  </p>
                                </div>
                              ) : (
                                <p className="mt-2 text-sm text-gray-500">No candidates</p>
                              )}
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        <div className="bg-white rounded-lg shadow-card p-6 text-center">
          {searchQuery || statusFilter !== 'all' ? (
            <>
              <AlertCircle className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900">No elections found</h3>
              <p className="mt-2 text-sm text-gray-500">
                Try adjusting your search or filter to find what you're looking for.
              </p>
              <button
                onClick={() => {
                  setSearchQuery('');
                  setStatusFilter('all');
                }}
                className="mt-4 btn-secondary"
              >
                Clear Filters
              </button>
            </>
          ) : (
            <>
              <BarChart4 className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900">No elections yet</h3>
              <p className="mt-2 text-sm text-gray-500">
                Create an election to start seeing results here.
              </p>
              <Link to="/admin/elections/create" className="mt-4 btn-primary inline-flex">
                Create Election
              </Link>
            </>
          )}
        </div>
      )}
    </div>
  );
};

export default AdminResults;