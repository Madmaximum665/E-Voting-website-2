import React, { useEffect, useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { 
  Plus, 
  AlertCircle, 
  Search, 
  Edit, 
  Trash2, 
  CheckCircle,
  X,
  Save,
  User,
  UserPlus
} from 'lucide-react';
import { useElectionStore } from '../../stores/electionStore';
import { useStudentStore } from '../../stores/studentStore';
import { Election, Position, Candidate, Student } from '../../types';

const ManageCandidates: React.FC = () => {
  const location = useLocation();
  const queryParams = new URLSearchParams(location.search);
  const electionIdParam = queryParams.get('election');
  const positionIdParam = queryParams.get('position');
  
  const { elections, loading: electionsLoading, getElections, addCandidate, updateCandidate, deleteCandidate } = useElectionStore();
  const { students, loading: studentsLoading, getStudents } = useStudentStore();
  
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedElection, setSelectedElection] = useState<Election | null>(null);
  const [selectedPosition, setSelectedPosition] = useState<Position | null>(null);
  const [showAddForm, setShowAddForm] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  // Form state
  const [formData, setFormData] = useState({
    studentId: '',
    manifesto: '',
    imageUrl: '',
  });
  const [validationErrors, setValidationErrors] = useState<Record<string, string>>({});
  
  useEffect(() => {
    getElections();
    getStudents();
  }, [getElections, getStudents]);
  
  useEffect(() => {
    if (elections.length > 0) {
      // If election ID was provided in URL, select that election
      if (electionIdParam) {
        const election = elections.find(e => e.id === electionIdParam);
        if (election) {
          setSelectedElection(election);
          
          // If position ID was also provided, select that position
          if (positionIdParam) {
            const position = election.positions.find(p => p.id === positionIdParam);
            if (position) {
              setSelectedPosition(position);
            }
          }
        }
      }
      // Otherwise, default to the first active election
      else {
        const activeElection = elections.find(e => e.status === 'active');
        if (activeElection) {
          setSelectedElection(activeElection);
          if (activeElection.positions.length > 0) {
            setSelectedPosition(activeElection.positions[0]);
          }
        } else if (elections.length > 0) {
          setSelectedElection(elections[0]);
          if (elections[0].positions.length > 0) {
            setSelectedPosition(elections[0].positions[0]);
          }
        }
      }
    }
  }, [elections, electionIdParam, positionIdParam]);
  
  const handleElectionChange = (electionId: string) => {
    const election = elections.find(e => e.id === electionId);
    if (election) {
      setSelectedElection(election);
      
      // Reset position selection
      if (election.positions.length > 0) {
        setSelectedPosition(election.positions[0]);
      } else {
        setSelectedPosition(null);
      }
    }
  };
  
  const handlePositionChange = (positionId: string) => {
    if (selectedElection) {
      const position = selectedElection.positions.find(p => p.id === positionId);
      if (position) {
        setSelectedPosition(position);
      }
    }
  };
  
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };
  
  const validateForm = (): boolean => {
    const errors: Record<string, string> = {};
    
    if (!formData.studentId) {
      errors.studentId = 'Please select a student';
    }
    
    if (!formData.manifesto.trim()) {
      errors.manifesto = 'Manifesto is required';
    }
    
    if (!formData.imageUrl.trim()) {
      errors.imageUrl = 'Image URL is required';
    } else if (!isValidUrl(formData.imageUrl)) {
      errors.imageUrl = 'Please enter a valid URL';
    }
    
    setValidationErrors(errors);
    return Object.keys(errors).length === 0;
  };
  
  const isValidUrl = (url: string): boolean => {
    try {
      new URL(url);
      return true;
    } catch (e) {
      return false;
    }
  };
  
  const handleAddCandidate = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!selectedElection || !selectedPosition) return;
    
    if (!validateForm()) {
      return;
    }
    
    setIsSubmitting(true);
    
    try {
      const student = students.find(s => s.id === formData.studentId);
      
      if (!student) {
        throw new Error('Selected student not found');
      }
      
      // Check if student is already a candidate for this position
      const isAlreadyCandidate = selectedPosition.candidates.some(
        c => c.studentId === student.studentId
      );
      
      if (isAlreadyCandidate) {
        setValidationErrors({
          studentId: 'This student is already a candidate for this position',
        });
        setIsSubmitting(false);
        return;
      }
      
      await addCandidate(selectedElection.id, selectedPosition.id, {
        name: student.name,
        studentId: student.studentId,
        department: student.department,
        year: student.year,
        position: selectedPosition.title,
        positionId: selectedPosition.id,
        manifesto: formData.manifesto,
        imageUrl: formData.imageUrl,
      });
      
      // Reset form
      setFormData({
        studentId: '',
        manifesto: '',
        imageUrl: '',
      });
      
      // Hide form
      setShowAddForm(false);
      
    } catch (error) {
      console.error('Error adding candidate:', error);
    } finally {
      setIsSubmitting(false);
    }
  };
  
  const handleDeleteCandidate = async (candidateId: string) => {
    if (!selectedElection || !selectedPosition) return;
    
    setIsSubmitting(true);
    
    try {
      await deleteCandidate(selectedElection.id, selectedPosition.id, candidateId);
      setConfirmDelete(null);
    } catch (error) {
      console.error('Error deleting candidate:', error);
    } finally {
      setIsSubmitting(false);
    }
  };
  
  // Filter candidates based on search query
  const filteredCandidates = selectedPosition?.candidates.filter(candidate => 
    candidate.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    candidate.studentId.toLowerCase().includes(searchQuery.toLowerCase()) ||
    candidate.department.toLowerCase().includes(searchQuery.toLowerCase())
  ) || [];
  
  // Filter students who are not already candidates for the selected position
  const eligibleStudents = students.filter(student => 
    !selectedPosition?.candidates.some(c => c.studentId === student.studentId)
  );
  
  if (electionsLoading || studentsLoading) {
    return (
      <div className="flex justify-center items-center h-64">
        <svg className="animate-spin h-10 w-10 text-primary-600\" xmlns="http://www.w3.org/2000/svg\" fill="none\" viewBox="0 0 24 24">
          <circle className="opacity-25\" cx="12\" cy="12\" r="10\" stroke="currentColor\" strokeWidth="4"></circle>
          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
        </svg>
      </div>
    );
  }
  
  return (
    <div>
      <div className="mb-6 flex flex-col sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Manage Candidates</h1>
          <p className="mt-1 text-sm text-gray-600">
            Add, edit, and remove candidates for each position.
          </p>
        </div>
      </div>
      
      {/* Election and Position Selection */}
      <div className="bg-white shadow-card rounded-lg p-6 mb-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label htmlFor="election" className="label">
              Select Election
            </label>
            <select
              id="election"
              className="input"
              value={selectedElection?.id || ''}
              onChange={(e) => handleElectionChange(e.target.value)}
            >
              <option value="" disabled>
                Select an election
              </option>
              {elections.map(election => (
                <option key={election.id} value={election.id}>
                  {election.title} ({election.status})
                </option>
              ))}
            </select>
          </div>
          
          <div>
            <label htmlFor="position" className="label">
              Select Position
            </label>
            <select
              id="position"
              className="input"
              value={selectedPosition?.id || ''}
              onChange={(e) => handlePositionChange(e.target.value)}
              disabled={!selectedElection || selectedElection.positions.length === 0}
            >
              <option value="" disabled>
                {!selectedElection 
                  ? 'Select an election first' 
                  : selectedElection.positions.length === 0 
                    ? 'No positions available' 
                    : 'Select a position'}
              </option>
              {selectedElection?.positions.map(position => (
                <option key={position.id} value={position.id}>
                  {position.title}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>
      
      {selectedElection && selectedPosition ? (
        <>
          {/* Candidates List */}
          <div className="bg-white shadow-card rounded-lg overflow-hidden mb-6">
            <div className="p-6 border-b border-gray-200">
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
                <h2 className="text-lg font-medium text-gray-900">
                  Candidates for {selectedPosition.title}
                </h2>
                <div className="mt-3 sm:mt-0">
                  <button
                    type="button"
                    onClick={() => setShowAddForm(true)}
                    className="btn-primary flex items-center"
                    disabled={showAddForm}
                  >
                    <UserPlus className="h-5 w-5 mr-1" />
                    Add Candidate
                  </button>
                </div>
              </div>
              
              <div className="mt-4">
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Search className="h-5 w-5 text-gray-400" />
                  </div>
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="input pl-10"
                    placeholder="Search candidates..."
                  />
                </div>
              </div>
            </div>
            
            {/* Add Candidate Form */}
            {showAddForm && (
              <div className="p-6 border-b border-gray-200 bg-gray-50">
                <form onSubmit={handleAddCandidate}>
                  <h3 className="text-md font-medium text-gray-900 mb-4">Add New Candidate</h3>
                  
                  <div className="space-y-4">
                    <div>
                      <label htmlFor="studentId" className="label">
                        Select Student
                      </label>
                      <select
                        id="studentId"
                        name="studentId"
                        value={formData.studentId}
                        onChange={handleInputChange}
                        className={`input ${validationErrors.studentId ? 'border-red-500' : ''}`}
                      >
                        <option value="">Select a student</option>
                        {eligibleStudents.map(student => (
                          <option key={student.id} value={student.id}>
                            {student.name} ({student.studentId}, {student.department})
                          </option>
                        ))}
                      </select>
                      {validationErrors.studentId && (
                        <p className="mt-1 text-sm text-red-600">{validationErrors.studentId}</p>
                      )}
                    </div>
                    
                    <div>
                      <label htmlFor="manifesto" className="label">
                        Manifesto
                      </label>
                      <textarea
                        id="manifesto"
                        name="manifesto"
                        value={formData.manifesto}
                        onChange={handleInputChange}
                        rows={3}
                        className={`input ${validationErrors.manifesto ? 'border-red-500' : ''}`}
                        placeholder="Enter the candidate's campaign manifesto or platform"
                      />
                      {validationErrors.manifesto && (
                        <p className="mt-1 text-sm text-red-600">{validationErrors.manifesto}</p>
                      )}
                    </div>
                    
                    <div>
                      <label htmlFor="imageUrl" className="label">
                        Profile Image URL
                      </label>
                      <input
                        type="text"
                        id="imageUrl"
                        name="imageUrl"
                        value={formData.imageUrl}
                        onChange={handleInputChange}
                        className={`input ${validationErrors.imageUrl ? 'border-red-500' : ''}`}
                        placeholder="https://example.com/image.jpg"
                      />
                      <p className="mt-1 text-xs text-gray-500">
                        Enter a URL for the candidate's profile image
                      </p>
                      {validationErrors.imageUrl && (
                        <p className="mt-1 text-sm text-red-600">{validationErrors.imageUrl}</p>
                      )}
                    </div>
                  </div>
                  
                  <div className="mt-6 flex justify-end space-x-3">
                    <button
                      type="button"
                      onClick={() => setShowAddForm(false)}
                      className="btn-secondary"
                      disabled={isSubmitting}
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      className="btn-primary flex items-center"
                      disabled={isSubmitting}
                    >
                      {isSubmitting ? (
                        <>
                          <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white\" xmlns="http://www.w3.org/2000/svg\" fill="none\" viewBox="0 0 24 24">
                            <circle className="opacity-25\" cx="12\" cy="12\" r="10\" stroke="currentColor\" strokeWidth="4"></circle>
                            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                          </svg>
                          Adding...
                        </>
                      ) : (
                        <>
                          <Save className="h-5 w-5 mr-1" />
                          Add Candidate
                        </>
                      )}
                    </button>
                  </div>
                </form>
              </div>
            )}
            
            {/* Candidates */}
            {filteredCandidates.length > 0 ? (
              <ul className="divide-y divide-gray-200">
                {filteredCandidates.map(candidate => (
                  <li key={candidate.id} className="p-6 hover:bg-gray-50">
                    <div className="flex items-start">
                      <div className="flex-shrink-0">
                        <img 
                          src={candidate.imageUrl} 
                          alt={candidate.name}
                          className="h-12 w-12 rounded-full object-cover"
                        />
                      </div>
                      <div className="ml-4 flex-1">
                        <div className="flex justify-between">
                          <div>
                            <h3 className="text-md font-medium text-gray-900">{candidate.name}</h3>
                            <p className="mt-1 text-sm text-gray-500">
                              ID: {candidate.studentId} • {candidate.department}, Year {candidate.year}
                            </p>
                          </div>
                          <div className="flex space-x-2">
                            <button
                              type="button"
                              onClick={() => setConfirmDelete(candidate.id)}
                              className="text-red-600 hover:text-red-800"
                              disabled={candidate.votes > 0}
                              title={candidate.votes > 0 ? "Cannot delete after votes have been cast" : "Delete candidate"}
                            >
                              <Trash2 className={`h-5 w-5 ${candidate.votes > 0 ? 'opacity-50 cursor-not-allowed' : ''}`} />
                            </button>
                          </div>
                        </div>
                        <p className="mt-2 text-sm text-gray-700">{candidate.manifesto}</p>
                        {candidate.votes > 0 && (
                          <p className="mt-2 text-sm text-amber-600">
                            This candidate has received {candidate.votes} votes and cannot be deleted.
                          </p>
                        )}
                      </div>
                    </div>
                  </li>
                ))}
              </ul>
            ) : (
              <div className="p-6 text-center">
                <User className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900">No candidates yet</h3>
                <p className="mt-2 text-sm text-gray-500">
                  Get started by adding candidates for this position.
                </p>
                {!showAddForm && (
                  <button
                    type="button"
                    onClick={() => setShowAddForm(true)}
                    className="mt-4 btn-primary flex items-center mx-auto"
                  >
                    <UserPlus className="h-5 w-5 mr-1" />
                    Add Candidate
                  </button>
                )}
              </div>
            )}
          </div>
        </>
      ) : (
        <div className="bg-white rounded-lg shadow-card p-6 text-center">
          <AlertCircle className="h-12 w-12 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900">No position selected</h3>
          <p className="mt-2 text-sm text-gray-500">
            Please select an election and position to manage candidates.
          </p>
        </div>
      )}
      
      {/* Delete Confirmation Modal */}
      {confirmDelete && (
        <div className="fixed inset-0 overflow-y-auto z-50">
          <div className="flex items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
            <div className="fixed inset-0 transition-opacity" aria-hidden="true">
              <div className="absolute inset-0 bg-gray-500 opacity-75"></div>
            </div>
            
            <span className="hidden sm:inline-block sm:align-middle sm:h-screen" aria-hidden="true">&#8203;</span>
            
            <div className="inline-block align-bottom bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full">
              <div className="bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4">
                <div className="sm:flex sm:items-start">
                  <div className="mx-auto flex-shrink-0 flex items-center justify-center h-12 w-12 rounded-full bg-red-100 sm:mx-0 sm:h-10 sm:w-10">
                    <AlertCircle className="h-6 w-6 text-red-600" />
                  </div>
                  <div className="mt-3 text-center sm:mt-0 sm:ml-4 sm:text-left">
                    <h3 className="text-lg leading-6 font-medium text-gray-900">
                      Delete Candidate
                    </h3>
                    <div className="mt-2">
                      <p className="text-sm text-gray-500">
                        Are you sure you want to remove this candidate? This action cannot be undone.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
              <div className="bg-gray-50 px-4 py-3 sm:px-6 sm:flex sm:flex-row-reverse">
                <button
                  type="button"
                  className="w-full inline-flex justify-center rounded-md border border-transparent shadow-sm px-4 py-2 bg-red-600 text-base font-medium text-white hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500 sm:ml-3 sm:w-auto sm:text-sm"
                  onClick={() => handleDeleteCandidate(confirmDelete)}
                  disabled={isSubmitting}
                >
                  {isSubmitting ? 'Deleting...' : 'Delete'}
                </button>
                <button
                  type="button"
                  className="mt-3 w-full inline-flex justify-center rounded-md border border-gray-300 shadow-sm px-4 py-2 bg-white text-base font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500 sm:mt-0 sm:ml-3 sm:w-auto sm:text-sm"
                  onClick={() => setConfirmDelete(null)}
                  disabled={isSubmitting}
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ManageCandidates;