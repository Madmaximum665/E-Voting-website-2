import React, { useEffect } from 'react';
import { Link } from 'react-router-dom';
import { 
  BarChart4, 
  Calendar, 
  Users, 
  Award, 
  Vote, 
  Clock, 
  CheckCircle, 
  AlertTriangle,
  ArrowRight
} from 'lucide-react';
import { useElectionStore } from '../../stores/electionStore';
import { useStudentStore } from '../../stores/studentStore';
import { useAuthStore } from '../../stores/authStore';

const AdminDashboard: React.FC = () => {
  const { elections, loading: electionsLoading, getElections } = useElectionStore();
  const { students, loading: studentsLoading, getStudents } = useStudentStore();
  const { user } = useAuthStore();
  
  useEffect(() => {
    getElections();
    getStudents();
  }, [getElections, getStudents]);
  
  if (electionsLoading || studentsLoading) {
    return (
      <div className="flex justify-center items-center h-64">
        <svg className="animate-spin h-10 w-10 text-primary-600" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
        </svg>
      </div>
    );
  }
  
  const activeElections = elections.filter(election => election.status === 'active').length;
  const upcomingElections = elections.filter(election => election.status === 'upcoming').length;
  const completedElections = elections.filter(election => election.status === 'completed').length;
  
  const totalCandidates = elections.reduce(
    (sum, election) => sum + election.positions.reduce(
      (posSum, position) => posSum + position.candidates.length, 
      0
    ), 
    0
  );
  
  const totalVotes = elections.reduce(
    (sum, election) => sum + election.positions.reduce(
      (posSum, position) => posSum + position.candidates.reduce(
        (candSum, candidate) => candSum + candidate.votes,
        0
      ), 
      0
    ), 
    0
  );
  
  // Get recent elections (last 3)
  const recentElections = [...elections]
    .sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime())
    .slice(0, 3);
  
  const formatDate = (dateString: string): string => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    }).format(date);
  };
  
  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'active':
        return <CheckCircle className="h-5 w-5 text-green-500" />;
      case 'upcoming':
        return <Clock className="h-5 w-5 text-blue-500" />;
      case 'completed':
        return <AlertTriangle className="h-5 w-5 text-gray-500" />;
      default:
        return null;
    }
  };
  
  return (
    <div>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Admin Dashboard</h1>
        <p className="mt-1 text-sm text-gray-600">
          Welcome, {user?.name}! Manage elections, candidates, and students.
        </p>
      </div>
      
      {/* Overview Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <div className="card">
          <div className="flex items-center">
            <Vote className="h-8 w-8 text-primary-500 mr-3" />
            <div>
              <p className="text-sm text-gray-500">Total Elections</p>
              <p className="text-2xl font-bold text-gray-900">{elections.length}</p>
            </div>
          </div>
          <div className="mt-2 grid grid-cols-3 gap-2 text-center text-xs">
            <div>
              <span className="text-green-600 font-medium block">{activeElections}</span>
              <span className="text-gray-500">Active</span>
            </div>
            <div>
              <span className="text-blue-600 font-medium block">{upcomingElections}</span>
              <span className="text-gray-500">Upcoming</span>
            </div>
            <div>
              <span className="text-gray-600 font-medium block">{completedElections}</span>
              <span className="text-gray-500">Completed</span>
            </div>
          </div>
        </div>
        
        <div className="card">
          <div className="flex items-center">
            <Users className="h-8 w-8 text-primary-500 mr-3" />
            <div>
              <p className="text-sm text-gray-500">Students</p>
              <p className="text-2xl font-bold text-gray-900">{students.length}</p>
            </div>
          </div>
          <div className="mt-4">
            <Link to="/admin/students" className="text-primary-600 text-sm font-medium flex items-center hover:text-primary-800">
              Manage Students <ArrowRight className="h-4 w-4 ml-1" />
            </Link>
          </div>
        </div>
        
        <div className="card">
          <div className="flex items-center">
            <Award className="h-8 w-8 text-primary-500 mr-3" />
            <div>
              <p className="text-sm text-gray-500">Candidates</p>
              <p className="text-2xl font-bold text-gray-900">{totalCandidates}</p>
            </div>
          </div>
          <div className="mt-4">
            <Link to="/admin/candidates" className="text-primary-600 text-sm font-medium flex items-center hover:text-primary-800">
              Manage Candidates <ArrowRight className="h-4 w-4 ml-1" />
            </Link>
          </div>
        </div>
        
        <div className="card">
          <div className="flex items-center">
            <BarChart4 className="h-8 w-8 text-primary-500 mr-3" />
            <div>
              <p className="text-sm text-gray-500">Total Votes</p>
              <p className="text-2xl font-bold text-gray-900">{totalVotes}</p>
            </div>
          </div>
          <div className="mt-4">
            <Link to="/admin/results" className="text-primary-600 text-sm font-medium flex items-center hover:text-primary-800">
              View All Results <ArrowRight className="h-4 w-4 ml-1" />
            </Link>
          </div>
        </div>
      </div>
      
      {/* Recent Elections */}
      <div className="mb-8">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-semibold text-gray-900">Recent Elections</h2>
          <Link to="/admin/elections" className="text-primary-600 text-sm font-medium flex items-center hover:text-primary-800">
            View All <ArrowRight className="h-4 w-4 ml-1" />
          </Link>
        </div>
        
        <div className="bg-white rounded-lg shadow-card overflow-hidden">
          {recentElections.length > 0 ? (
            <div className="divide-y divide-gray-200">
              {recentElections.map(election => (
                <div key={election.id} className="p-4 hover:bg-gray-50">
                  <div className="flex justify-between items-start">
                    <div className="flex items-start">
                      {getStatusIcon(election.status)}
                      <div className="ml-3">
                        <h3 className="text-md font-medium text-gray-900">{election.title}</h3>
                        <p className="mt-1 text-sm text-gray-500">
                          {formatDate(election.startDate)} to {formatDate(election.endDate)}
                        </p>
                      </div>
                    </div>
                    <Link 
                      to={`/admin/elections/edit/${election.id}`} 
                      className="text-sm text-primary-600 hover:text-primary-800"
                    >
                      Edit
                    </Link>
                  </div>
                  <div className="mt-2 flex items-center text-xs text-gray-500">
                    <span>{election.positions.length} positions</span>
                    <span className="mx-2">•</span>
                    <span>
                      {election.positions.reduce((sum, pos) => sum + pos.candidates.length, 0)} candidates
                    </span>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="p-4 text-center text-gray-500">
              No elections found. Create your first election.
            </div>
          )}
          
          <div className="bg-gray-50 px-4 py-3">
            <Link 
              to="/admin/elections/create" 
              className="btn-primary w-full text-center"
            >
              Create New Election
            </Link>
          </div>
        </div>
      </div>
      
      {/* Quick Actions */}
      <div>
        <h2 className="text-xl font-semibold text-gray-900 mb-4">Quick Actions</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          <Link to="/admin/elections" className="card hover:shadow-lg transition-shadow duration-200">
            <Vote className="h-8 w-8 text-primary-500 mb-4" />
            <h3 className="text-lg font-medium text-gray-900">Manage Elections</h3>
            <p className="mt-1 text-sm text-gray-500">
              Create, edit, and manage all elections.
            </p>
          </Link>
          
          <Link to="/admin/students" className="card hover:shadow-lg transition-shadow duration-200">
            <Users className="h-8 w-8 text-primary-500 mb-4" />
            <h3 className="text-lg font-medium text-gray-900">Manage Students</h3>
            <p className="mt-1 text-sm text-gray-500">
              Add, edit, or remove student accounts.
            </p>
          </Link>
          
          <Link to="/admin/results" className="card hover:shadow-lg transition-shadow duration-200">
            <BarChart4 className="h-8 w-8 text-primary-500 mb-4" />
            <h3 className="text-lg font-medium text-gray-900">View Results</h3>
            <p className="mt-1 text-sm text-gray-500">
              View detailed results for all elections.
            </p>
          </Link>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;