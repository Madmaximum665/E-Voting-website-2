import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { ChevronRight, Calendar, Plus, Trash2, AlertCircle, Save } from 'lucide-react';
import { useElectionStore } from '../../stores/electionStore';
import { Position } from '../../types';

const CreateElection: React.FC = () => {
  const navigate = useNavigate();
  const { createElection, loading, error } = useElectionStore();
  
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [positions, setPositions] = useState<Omit<Position, 'id' | 'candidates'>[]>([]);
  const [validationErrors, setValidationErrors] = useState<Record<string, string>>({});
  
  const addPosition = () => {
    setPositions([
      ...positions,
      {
        title: '',
        description: '',
        maxSelections: 1,
      },
    ]);
  };
  
  const updatePosition = (index: number, field: string, value: string | number) => {
    const updatedPositions = [...positions];
    updatedPositions[index] = {
      ...updatedPositions[index],
      [field]: value,
    };
    setPositions(updatedPositions);
  };
  
  const removePosition = (index: number) => {
    const updatedPositions = [...positions];
    updatedPositions.splice(index, 1);
    setPositions(updatedPositions);
  };
  
  const validateForm = (): boolean => {
    const errors: Record<string, string> = {};
    
    if (!title.trim()) {
      errors.title = 'Election title is required';
    }
    
    if (!description.trim()) {
      errors.description = 'Description is required';
    }
    
    if (!startDate) {
      errors.startDate = 'Start date is required';
    }
    
    if (!endDate) {
      errors.endDate = 'End date is required';
    }
    
    if (startDate && endDate && new Date(startDate) >= new Date(endDate)) {
      errors.endDate = 'End date must be after start date';
    }
    
    if (positions.length === 0) {
      errors.positions = 'At least one position is required';
    } else {
      positions.forEach((position, index) => {
        if (!position.title.trim()) {
          errors[`position_${index}_title`] = 'Position title is required';
        }
        
        if (!position.description.trim()) {
          errors[`position_${index}_description`] = 'Position description is required';
        }
        
        if (!position.maxSelections || position.maxSelections < 1) {
          errors[`position_${index}_maxSelections`] = 'Maximum selections must be at least 1';
        }
      });
    }
    
    setValidationErrors(errors);
    return Object.keys(errors).length === 0;
  };
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }
    
    // Determine status based on dates
    const now = new Date();
    const start = new Date(startDate);
    const end = new Date(endDate);
    
    let status: 'upcoming' | 'active' | 'completed';
    if (now < start) {
      status = 'upcoming';
    } else if (now >= start && now <= end) {
      status = 'active';
    } else {
      status = 'completed';
    }
    
    try {
      await createElection({
        title,
        description,
        startDate,
        endDate,
        positions,
        status,
      });
      
      navigate('/admin/elections');
    } catch (error) {
      console.error('Error creating election:', error);
    }
  };
  
  return (
    <div>
      <div className="mb-1">
        <Link to="/admin/elections" className="text-sm text-primary-600 hover:text-primary-800 flex items-center">
          <ChevronRight className="h-4 w-4 mr-1 transform rotate-180" />
          Back to Elections
        </Link>
      </div>
      
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Create New Election</h1>
        <p className="mt-1 text-sm text-gray-600">
          Set up a new election with positions and voting details.
        </p>
      </div>
      
      {error && (
        <div className="rounded-md bg-red-50 p-4 mb-6">
          <div className="flex">
            <div className="flex-shrink-0">
              <AlertCircle className="h-5 w-5 text-red-400" />
            </div>
            <div className="ml-3">
              <h3 className="text-sm font-medium text-red-800">Error creating election</h3>
              <p className="mt-2 text-sm text-red-700">{error}</p>
            </div>
          </div>
        </div>
      )}
      
      <form onSubmit={handleSubmit}>
        <div className="bg-white shadow-card rounded-lg p-6 mb-6">
          <h2 className="text-lg font-medium text-gray-900 mb-4">Election Details</h2>
          
          <div className="space-y-4">
            <div>
              <label htmlFor="title" className="label">
                Election Title
              </label>
              <input
                type="text"
                id="title"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className={`input ${validationErrors.title ? 'border-red-500' : ''}`}
                placeholder="e.g. Student Council Election 2025"
              />
              {validationErrors.title && (
                <p className="mt-1 text-sm text-red-600">{validationErrors.title}</p>
              )}
            </div>
            
            <div>
              <label htmlFor="description" className="label">
                Description
              </label>
              <textarea
                id="description"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                rows={3}
                className={`input ${validationErrors.description ? 'border-red-500' : ''}`}
                placeholder="Provide a description of the election"
              />
              {validationErrors.description && (
                <p className="mt-1 text-sm text-red-600">{validationErrors.description}</p>
              )}
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label htmlFor="startDate" className="label">
                  Start Date and Time
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Calendar className="h-5 w-5 text-gray-400" />
                  </div>
                  <input
                    type="datetime-local"
                    id="startDate"
                    value={startDate}
                    onChange={(e) => setStartDate(e.target.value)}
                    className={`input pl-10 ${validationErrors.startDate ? 'border-red-500' : ''}`}
                  />
                </div>
                {validationErrors.startDate && (
                  <p className="mt-1 text-sm text-red-600">{validationErrors.startDate}</p>
                )}
              </div>
              
              <div>
                <label htmlFor="endDate" className="label">
                  End Date and Time
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Calendar className="h-5 w-5 text-gray-400" />
                  </div>
                  <input
                    type="datetime-local"
                    id="endDate"
                    value={endDate}
                    onChange={(e) => setEndDate(e.target.value)}
                    className={`input pl-10 ${validationErrors.endDate ? 'border-red-500' : ''}`}
                  />
                </div>
                {validationErrors.endDate && (
                  <p className="mt-1 text-sm text-red-600">{validationErrors.endDate}</p>
                )}
              </div>
            </div>
          </div>
        </div>
        
        <div className="bg-white shadow-card rounded-lg p-6 mb-6">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-lg font-medium text-gray-900">Positions</h2>
            <button
              type="button"
              onClick={addPosition}
              className="btn-secondary flex items-center"
            >
              <Plus className="h-4 w-4 mr-1" />
              Add Position
            </button>
          </div>
          
          {validationErrors.positions && (
            <p className="mb-4 text-sm text-red-600">{validationErrors.positions}</p>
          )}
          
          {positions.length === 0 ? (
            <div className="text-center py-6 bg-gray-50 rounded-lg">
              <p className="text-gray-500">No positions added yet. Click "Add Position" to get started.</p>
            </div>
          ) : (
            <div className="space-y-6">
              {positions.map((position, index) => (
                <div key={index} className="border border-gray-200 rounded-lg p-4">
                  <div className="flex justify-between items-center mb-4">
                    <h3 className="text-md font-medium text-gray-900">Position {index + 1}</h3>
                    <button
                      type="button"
                      onClick={() => removePosition(index)}
                      className="text-red-600 hover:text-red-800"
                    >
                      <Trash2 className="h-5 w-5" />
                    </button>
                  </div>
                  
                  <div className="space-y-4">
                    <div>
                      <label htmlFor={`position-${index}-title`} className="label">
                        Position Title
                      </label>
                      <input
                        type="text"
                        id={`position-${index}-title`}
                        value={position.title}
                        onChange={(e) => updatePosition(index, 'title', e.target.value)}
                        className={`input ${validationErrors[`position_${index}_title`] ? 'border-red-500' : ''}`}
                        placeholder="e.g. President, Treasurer, etc."
                      />
                      {validationErrors[`position_${index}_title`] && (
                        <p className="mt-1 text-sm text-red-600">{validationErrors[`position_${index}_title`]}</p>
                      )}
                    </div>
                    
                    <div>
                      <label htmlFor={`position-${index}-description`} className="label">
                        Description
                      </label>
                      <textarea
                        id={`position-${index}-description`}
                        value={position.description}
                        onChange={(e) => updatePosition(index, 'description', e.target.value)}
                        rows={2}
                        className={`input ${validationErrors[`position_${index}_description`] ? 'border-red-500' : ''}`}
                        placeholder="Describe the responsibilities of this position"
                      />
                      {validationErrors[`position_${index}_description`] && (
                        <p className="mt-1 text-sm text-red-600">{validationErrors[`position_${index}_description`]}</p>
                      )}
                    </div>
                    
                    <div>
                      <label htmlFor={`position-${index}-maxSelections`} className="label">
                        Maximum Number of Selections
                      </label>
                      <input
                        type="number"
                        id={`position-${index}-maxSelections`}
                        value={position.maxSelections}
                        onChange={(e) => updatePosition(index, 'maxSelections', parseInt(e.target.value))}
                        min="1"
                        className={`input ${validationErrors[`position_${index}_maxSelections`] ? 'border-red-500' : ''}`}
                        placeholder="1"
                      />
                      <p className="mt-1 text-xs text-gray-500">
                        How many candidates a voter can select for this position (e.g., 1 for single selection, 2+ for multiple selections)
                      </p>
                      {validationErrors[`position_${index}_maxSelections`] && (
                        <p className="mt-1 text-sm text-red-600">{validationErrors[`position_${index}_maxSelections`]}</p>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
          
          {positions.length > 0 && (
            <div className="mt-4">
              <button
                type="button"
                onClick={addPosition}
                className="text-primary-600 font-medium flex items-center hover:text-primary-800"
              >
                <Plus className="h-4 w-4 mr-1" />
                Add Another Position
              </button>
            </div>
          )}
        </div>
        
        <div className="flex justify-end space-x-4">
          <Link 
            to="/admin/elections" 
            className="btn-secondary"
          >
            Cancel
          </Link>
          <button
            type="submit"
            className="btn-primary flex items-center"
            disabled={loading}
          >
            {loading ? (
              <>
                <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white\" xmlns="http://www.w3.org/2000/svg\" fill="none\" viewBox="0 0 24 24">
                  <circle className="opacity-25\" cx="12\" cy="12\" r="10\" stroke="currentColor\" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                Creating...
              </>
            ) : (
              <>
                <Save className="h-5 w-5 mr-1" />
                Create Election
              </>
            )}
          </button>
        </div>
      </form>
    </div>
  );
};

export default CreateElection;