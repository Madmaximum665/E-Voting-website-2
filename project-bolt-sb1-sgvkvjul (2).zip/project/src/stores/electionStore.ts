import { create } from 'zustand';
import { Election, Position, Candidate, Vote } from '../types';

interface ElectionState {
  elections: Election[];
  loading: boolean;
  error: string | null;
  
  // Election CRUD operations
  getElections: () => Promise<void>;
  getElectionById: (id: string) => Election | undefined;
  createElection: (election: Omit<Election, 'id' | 'createdAt' | 'updatedAt'>) => Promise<void>;
  updateElection: (id: string, election: Partial<Election>) => Promise<void>;
  deleteElection: (id: string) => Promise<void>;
  
  // Position operations
  addPosition: (electionId: string, position: Omit<Position, 'id' | 'candidates'>) => Promise<void>;
  updatePosition: (electionId: string, positionId: string, position: Partial<Position>) => Promise<void>;
  deletePosition: (electionId: string, positionId: string) => Promise<void>;
  
  // Candidate operations
  addCandidate: (electionId: string, positionId: string, candidate: Omit<Candidate, 'id' | 'votes'>) => Promise<void>;
  updateCandidate: (electionId: string, positionId: string, candidateId: string, candidate: Partial<Candidate>) => Promise<void>;
  deleteCandidate: (electionId: string, positionId: string, candidateId: string) => Promise<void>;
  
  // Voting operations
  castVote: (vote: Omit<Vote, 'id' | 'timestamp'>) => Promise<void>;
  hasVoted: (electionId: string, positionId: string, voterId: string) => boolean;
}

export const useElectionStore = create<ElectionState>((set, get) => ({
  elections: [],
  loading: false,
  error: null,
  
  // Elections
  getElections: async () => {
    set({ loading: true, error: null });
    
    try {
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 500));
      
      // Get elections from localStorage
      const elections = JSON.parse(localStorage.getItem('elections') || '[]');
      
      // Check and update election status based on dates
      const updatedElections = elections.map((election: Election) => {
        const now = new Date();
        const startDate = new Date(election.startDate);
        const endDate = new Date(election.endDate);
        
        let status = election.status;
        
        if (now < startDate) {
          status = 'upcoming';
        } else if (now >= startDate && now <= endDate) {
          status = 'active';
        } else if (now > endDate) {
          status = 'completed';
        }
        
        return { ...election, status };
      });
      
      // Save updated elections back to localStorage
      localStorage.setItem('elections', JSON.stringify(updatedElections));
      
      set({ elections: updatedElections, loading: false });
      
    } catch (error) {
      set({ 
        error: error instanceof Error ? error.message : 'An error occurred while fetching elections', 
        loading: false 
      });
    }
  },
  
  getElectionById: (id) => {
    return get().elections.find(election => election.id === id);
  },
  
  createElection: async (election) => {
    set({ loading: true, error: null });
    
    try {
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 500));
      
      const newElection: Election = {
        ...election,
        id: crypto.randomUUID(),
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };
      
      const elections = [...get().elections, newElection];
      
      // Save to localStorage
      localStorage.setItem('elections', JSON.stringify(elections));
      
      set({ elections, loading: false });
      
    } catch (error) {
      set({ 
        error: error instanceof Error ? error.message : 'An error occurred while creating the election', 
        loading: false 
      });
    }
  },
  
  updateElection: async (id, electionUpdate) => {
    set({ loading: true, error: null });
    
    try {
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 500));
      
      const elections = get().elections.map(election => 
        election.id === id 
          ? { 
              ...election, 
              ...electionUpdate, 
              updatedAt: new Date().toISOString() 
            } 
          : election
      );
      
      // Save to localStorage
      localStorage.setItem('elections', JSON.stringify(elections));
      
      set({ elections, loading: false });
      
    } catch (error) {
      set({ 
        error: error instanceof Error ? error.message : 'An error occurred while updating the election', 
        loading: false 
      });
    }
  },
  
  deleteElection: async (id) => {
    set({ loading: true, error: null });
    
    try {
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 500));
      
      const elections = get().elections.filter(election => election.id !== id);
      
      // Save to localStorage
      localStorage.setItem('elections', JSON.stringify(elections));
      
      set({ elections, loading: false });
      
    } catch (error) {
      set({ 
        error: error instanceof Error ? error.message : 'An error occurred while deleting the election', 
        loading: false 
      });
    }
  },
  
  // Positions
  addPosition: async (electionId, position) => {
    set({ loading: true, error: null });
    
    try {
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 300));
      
      const newPosition: Position = {
        ...position,
        id: crypto.randomUUID(),
        candidates: [],
      };
      
      const elections = get().elections.map(election => 
        election.id === electionId 
          ? { 
              ...election, 
              positions: [...election.positions, newPosition],
              updatedAt: new Date().toISOString()
            } 
          : election
      );
      
      // Save to localStorage
      localStorage.setItem('elections', JSON.stringify(elections));
      
      set({ elections, loading: false });
      
    } catch (error) {
      set({ 
        error: error instanceof Error ? error.message : 'An error occurred while adding the position', 
        loading: false 
      });
    }
  },
  
  updatePosition: async (electionId, positionId, positionUpdate) => {
    set({ loading: true, error: null });
    
    try {
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 300));
      
      const elections = get().elections.map(election => 
        election.id === electionId 
          ? { 
              ...election, 
              positions: election.positions.map(position => 
                position.id === positionId 
                  ? { ...position, ...positionUpdate } 
                  : position
              ),
              updatedAt: new Date().toISOString()
            } 
          : election
      );
      
      // Save to localStorage
      localStorage.setItem('elections', JSON.stringify(elections));
      
      set({ elections, loading: false });
      
    } catch (error) {
      set({ 
        error: error instanceof Error ? error.message : 'An error occurred while updating the position', 
        loading: false 
      });
    }
  },
  
  deletePosition: async (electionId, positionId) => {
    set({ loading: true, error: null });
    
    try {
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 300));
      
      const elections = get().elections.map(election => 
        election.id === electionId 
          ? { 
              ...election, 
              positions: election.positions.filter(position => position.id !== positionId),
              updatedAt: new Date().toISOString()
            } 
          : election
      );
      
      // Save to localStorage
      localStorage.setItem('elections', JSON.stringify(elections));
      
      set({ elections, loading: false });
      
    } catch (error) {
      set({ 
        error: error instanceof Error ? error.message : 'An error occurred while deleting the position', 
        loading: false 
      });
    }
  },
  
  // Candidates
  addCandidate: async (electionId, positionId, candidate) => {
    set({ loading: true, error: null });
    
    try {
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 300));
      
      const newCandidate: Candidate = {
        ...candidate,
        id: crypto.randomUUID(),
        votes: 0,
      };
      
      const elections = get().elections.map(election => 
        election.id === electionId 
          ? { 
              ...election, 
              positions: election.positions.map(position => 
                position.id === positionId 
                  ? { 
                      ...position, 
                      candidates: [...position.candidates, newCandidate] 
                    } 
                  : position
              ),
              updatedAt: new Date().toISOString()
            } 
          : election
      );
      
      // Save to localStorage
      localStorage.setItem('elections', JSON.stringify(elections));
      
      set({ elections, loading: false });
      
    } catch (error) {
      set({ 
        error: error instanceof Error ? error.message : 'An error occurred while adding the candidate', 
        loading: false 
      });
    }
  },
  
  updateCandidate: async (electionId, positionId, candidateId, candidateUpdate) => {
    set({ loading: true, error: null });
    
    try {
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 300));
      
      const elections = get().elections.map(election => 
        election.id === electionId 
          ? { 
              ...election, 
              positions: election.positions.map(position => 
                position.id === positionId 
                  ? { 
                      ...position, 
                      candidates: position.candidates.map(candidate => 
                        candidate.id === candidateId 
                          ? { ...candidate, ...candidateUpdate } 
                          : candidate
                      ) 
                    } 
                  : position
              ),
              updatedAt: new Date().toISOString()
            } 
          : election
      );
      
      // Save to localStorage
      localStorage.setItem('elections', JSON.stringify(elections));
      
      set({ elections, loading: false });
      
    } catch (error) {
      set({ 
        error: error instanceof Error ? error.message : 'An error occurred while updating the candidate', 
        loading: false 
      });
    }
  },
  
  deleteCandidate: async (electionId, positionId, candidateId) => {
    set({ loading: true, error: null });
    
    try {
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 300));
      
      const elections = get().elections.map(election => 
        election.id === electionId 
          ? { 
              ...election, 
              positions: election.positions.map(position => 
                position.id === positionId 
                  ? { 
                      ...position, 
                      candidates: position.candidates.filter(candidate => candidate.id !== candidateId) 
                    } 
                  : position
              ),
              updatedAt: new Date().toISOString()
            } 
          : election
      );
      
      // Save to localStorage
      localStorage.setItem('elections', JSON.stringify(elections));
      
      set({ elections, loading: false });
      
    } catch (error) {
      set({ 
        error: error instanceof Error ? error.message : 'An error occurred while deleting the candidate', 
        loading: false 
      });
    }
  },
  
  // Voting
  castVote: async (voteData) => {
    set({ loading: true, error: null });
    
    try {
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 500));
      
      // Create new vote
      const newVote: Vote = {
        ...voteData,
        id: crypto.randomUUID(),
        timestamp: new Date().toISOString(),
      };
      
      // Get existing votes
      const votes = JSON.parse(localStorage.getItem('votes') || '[]');
      
      // Add new vote
      const updatedVotes = [...votes, newVote];
      
      // Save votes to localStorage
      localStorage.setItem('votes', JSON.stringify(updatedVotes));
      
      // Update candidate vote count
      const elections = get().elections.map(election => 
        election.id === voteData.electionId 
          ? { 
              ...election, 
              positions: election.positions.map(position => 
                position.id === voteData.positionId 
                  ? { 
                      ...position, 
                      candidates: position.candidates.map(candidate => 
                        candidate.id === voteData.candidateId 
                          ? { ...candidate, votes: candidate.votes + 1 } 
                          : candidate
                      ) 
                    } 
                  : position
              ),
              updatedAt: new Date().toISOString()
            } 
          : election
      );
      
      // Save updated elections to localStorage
      localStorage.setItem('elections', JSON.stringify(elections));
      
      set({ elections, loading: false });
      
    } catch (error) {
      set({ 
        error: error instanceof Error ? error.message : 'An error occurred while casting your vote', 
        loading: false 
      });
    }
  },
  
  hasVoted: (electionId, positionId, voterId) => {
    // Get votes from localStorage
    const votes = JSON.parse(localStorage.getItem('votes') || '[]');
    
    // Check if user has already voted for this position in this election
    return votes.some((vote: Vote) => 
      vote.electionId === electionId && 
      vote.positionId === positionId && 
      vote.voterId === voterId
    );
  },
}));