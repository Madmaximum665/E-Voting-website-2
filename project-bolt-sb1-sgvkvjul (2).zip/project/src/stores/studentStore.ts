import { create } from 'zustand';
import { Student } from '../types';

interface StudentState {
  students: Student[];
  loading: boolean;
  error: string | null;
  
  getStudents: () => Promise<void>;
  getStudentById: (id: string) => Student | undefined;
  addStudent: (student: Omit<Student, 'id'>) => Promise<void>;
  updateStudent: (id: string, student: Partial<Student>) => Promise<void>;
  deleteStudent: (id: string) => Promise<void>;
}

export const useStudentStore = create<StudentState>((set, get) => ({
  students: [],
  loading: false,
  error: null,
  
  getStudents: async () => {
    set({ loading: true, error: null });
    
    try {
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 500));
      
      // Get students from localStorage
      const students = JSON.parse(localStorage.getItem('students') || '[]');
      
      set({ students, loading: false });
      
    } catch (error) {
      set({ 
        error: error instanceof Error ? error.message : 'An error occurred while fetching students', 
        loading: false 
      });
    }
  },
  
  getStudentById: (id) => {
    return get().students.find(student => student.id === id);
  },
  
  addStudent: async (student) => {
    set({ loading: true, error: null });
    
    try {
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 500));
      
      const newStudent: Student = {
        ...student,
        id: crypto.randomUUID(),
      };
      
      const students = [...get().students, newStudent];
      
      // Save to localStorage
      localStorage.setItem('students', JSON.stringify(students));
      
      // Create a user account for the student
      const users = JSON.parse(localStorage.getItem('users') || '[]');
      const newUser = {
        id: newStudent.id,
        name: newStudent.name,
        email: newStudent.email,
        password: newStudent.studentId, // Default password is student ID
        role: 'student',
        studentId: newStudent.studentId,
        department: newStudent.department,
        year: newStudent.year,
      };
      
      const updatedUsers = [...users, newUser];
      localStorage.setItem('users', JSON.stringify(updatedUsers));
      
      set({ students, loading: false });
      
    } catch (error) {
      set({ 
        error: error instanceof Error ? error.message : 'An error occurred while adding the student', 
        loading: false 
      });
    }
  },
  
  updateStudent: async (id, studentUpdate) => {
    set({ loading: true, error: null });
    
    try {
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 500));
      
      const students = get().students.map(student => 
        student.id === id 
          ? { ...student, ...studentUpdate } 
          : student
      );
      
      // Save to localStorage
      localStorage.setItem('students', JSON.stringify(students));
      
      // Update user information too
      const users = JSON.parse(localStorage.getItem('users') || '[]');
      const updatedUsers = users.map((user: any) => {
        if (user.id === id) {
          return {
            ...user,
            name: studentUpdate.name || user.name,
            email: studentUpdate.email || user.email,
            studentId: studentUpdate.studentId || user.studentId,
            department: studentUpdate.department || user.department,
            year: studentUpdate.year || user.year,
          };
        }
        return user;
      });
      
      localStorage.setItem('users', JSON.stringify(updatedUsers));
      
      set({ students, loading: false });
      
    } catch (error) {
      set({ 
        error: error instanceof Error ? error.message : 'An error occurred while updating the student', 
        loading: false 
      });
    }
  },
  
  deleteStudent: async (id) => {
    set({ loading: true, error: null });
    
    try {
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 500));
      
      const students = get().students.filter(student => student.id !== id);
      
      // Save to localStorage
      localStorage.setItem('students', JSON.stringify(students));
      
      // Delete user account
      const users = JSON.parse(localStorage.getItem('users') || '[]');
      const updatedUsers = users.filter((user: any) => user.id !== id);
      localStorage.setItem('users', JSON.stringify(updatedUsers));
      
      set({ students, loading: false });
      
    } catch (error) {
      set({ 
        error: error instanceof Error ? error.message : 'An error occurred while deleting the student', 
        loading: false 
      });
    }
  },
}));