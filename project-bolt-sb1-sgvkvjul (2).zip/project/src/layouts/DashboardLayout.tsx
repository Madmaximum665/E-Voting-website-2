import React, { useState } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { 
  Vote, 
  Home, 
  LogOut, 
  ChevronDown, 
  BarChart4, 
  Users, 
  Award, 
  Menu, 
  X, 
  User
} from 'lucide-react';
import { useAuthStore } from '../stores/authStore';

interface DashboardLayoutProps {
  children: React.ReactNode;
}

const DashboardLayout: React.FC<DashboardLayoutProps> = ({ children }) => {
  const { user, logout } = useAuthStore();
  const navigate = useNavigate();
  const location = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const isAdmin = user?.role === 'admin';

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Top navigation bar */}
      <nav className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex">
              <div className="flex-shrink-0 flex items-center">
                <Vote className="h-8 w-8 text-primary-600" />
                <span className="ml-2 text-xl font-bold text-gray-900">E-Voting</span>
              </div>
            </div>
            
            <div className="hidden sm:ml-6 sm:flex sm:items-center">
              <div className="relative">
                <div className="flex items-center">
                  <span className="hidden md:inline-block text-sm text-gray-700 mr-2">
                    {user?.name}
                  </span>
                  <User className="h-6 w-6 text-gray-500" />
                </div>
              </div>
              <button
                onClick={handleLogout}
                className="ml-4 p-2 text-gray-500 hover:text-gray-700 focus:outline-none"
              >
                <LogOut className="h-5 w-5" />
              </button>
            </div>
            
            <div className="-mr-2 flex items-center sm:hidden">
              <button
                type="button"
                className="inline-flex items-center justify-center p-2 rounded-md text-gray-500 hover:text-gray-700 hover:bg-gray-100 focus:outline-none"
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              >
                {mobileMenuOpen ? (
                  <X className="block h-6 w-6" />
                ) : (
                  <Menu className="block h-6 w-6" />
                )}
              </button>
            </div>
          </div>
        </div>
        
        {/* Mobile menu */}
        <div className={`${mobileMenuOpen ? 'block' : 'hidden'} sm:hidden`}>
          <div className="pt-2 pb-3 space-y-1">
            <Link 
              to={isAdmin ? '/admin' : '/dashboard'} 
              className={`${
                location.pathname === (isAdmin ? '/admin' : '/dashboard')
                  ? 'bg-primary-50 text-primary-700'
                  : 'text-gray-700 hover:bg-gray-50'
              } block pl-3 pr-4 py-2 text-base font-medium border-l-4 ${
                location.pathname === (isAdmin ? '/admin' : '/dashboard')
                  ? 'border-primary-500'
                  : 'border-transparent'
              }`}
              onClick={() => setMobileMenuOpen(false)}
            >
              Dashboard
            </Link>
            
            {isAdmin ? (
              <>
                <Link 
                  to="/admin/elections" 
                  className={`${
                    location.pathname.includes('/admin/elections')
                      ? 'bg-primary-50 text-primary-700'
                      : 'text-gray-700 hover:bg-gray-50'
                  } block pl-3 pr-4 py-2 text-base font-medium border-l-4 ${
                    location.pathname.includes('/admin/elections')
                      ? 'border-primary-500'
                      : 'border-transparent'
                  }`}
                  onClick={() => setMobileMenuOpen(false)}
                >
                  Manage Elections
                </Link>
                <Link 
                  to="/admin/candidates" 
                  className={`${
                    location.pathname === '/admin/candidates'
                      ? 'bg-primary-50 text-primary-700'
                      : 'text-gray-700 hover:bg-gray-50'
                  } block pl-3 pr-4 py-2 text-base font-medium border-l-4 ${
                    location.pathname === '/admin/candidates'
                      ? 'border-primary-500'
                      : 'border-transparent'
                  }`}
                  onClick={() => setMobileMenuOpen(false)}
                >
                  Manage Candidates
                </Link>
                <Link 
                  to="/admin/students" 
                  className={`${
                    location.pathname === '/admin/students'
                      ? 'bg-primary-50 text-primary-700'
                      : 'text-gray-700 hover:bg-gray-50'
                  } block pl-3 pr-4 py-2 text-base font-medium border-l-4 ${
                    location.pathname === '/admin/students'
                      ? 'border-primary-500'
                      : 'border-transparent'
                  }`}
                  onClick={() => setMobileMenuOpen(false)}
                >
                  Manage Students
                </Link>
                <Link 
                  to="/admin/results" 
                  className={`${
                    location.pathname === '/admin/results'
                      ? 'bg-primary-50 text-primary-700'
                      : 'text-gray-700 hover:bg-gray-50'
                  } block pl-3 pr-4 py-2 text-base font-medium border-l-4 ${
                    location.pathname === '/admin/results'
                      ? 'border-primary-500'
                      : 'border-transparent'
                  }`}
                  onClick={() => setMobileMenuOpen(false)}
                >
                  View Results
                </Link>
              </>
            ) : null}
          </div>
          
          <div className="pt-4 pb-3 border-t border-gray-200">
            <div className="flex items-center px-4">
              <div className="flex-shrink-0">
                <User className="h-10 w-10 text-gray-400" />
              </div>
              <div className="ml-3">
                <div className="text-base font-medium text-gray-800">{user?.name}</div>
                <div className="text-sm font-medium text-gray-500">{user?.email}</div>
              </div>
            </div>
            <div className="mt-3 space-y-1">
              <button
                onClick={() => {
                  handleLogout();
                  setMobileMenuOpen(false);
                }}
                className="block pl-3 pr-4 py-2 text-base font-medium text-gray-700 hover:bg-gray-50 w-full text-left"
              >
                Log out
              </button>
            </div>
          </div>
        </div>
      </nav>
      
      <div className="flex">
        {/* Sidebar */}
        <div className="hidden md:flex md:w-64 md:flex-col md:fixed md:inset-y-0 pt-16">
          <div className="flex-1 flex flex-col min-h-0 border-r border-gray-200 bg-white">
            <div className="flex-1 flex flex-col pt-5 pb-4 overflow-y-auto">
              <nav className="mt-5 flex-1 px-2 space-y-1">
                <Link
                  to={isAdmin ? '/admin' : '/dashboard'}
                  className={`${
                    location.pathname === (isAdmin ? '/admin' : '/dashboard')
                      ? 'bg-primary-50 text-primary-700'
                      : 'text-gray-700 hover:bg-gray-50'
                  } group flex items-center px-2 py-2 text-sm font-medium rounded-md`}
                >
                  <Home 
                    className={`${
                      location.pathname === (isAdmin ? '/admin' : '/dashboard')
                        ? 'text-primary-600'
                        : 'text-gray-500 group-hover:text-gray-600'
                    } mr-3 h-5 w-5`} 
                  />
                  Dashboard
                </Link>
                
                {isAdmin ? (
                  <>
                    <Link
                      to="/admin/elections"
                      className={`${
                        location.pathname.includes('/admin/elections')
                          ? 'bg-primary-50 text-primary-700'
                          : 'text-gray-700 hover:bg-gray-50'
                      } group flex items-center px-2 py-2 text-sm font-medium rounded-md`}
                    >
                      <Vote 
                        className={`${
                          location.pathname.includes('/admin/elections')
                            ? 'text-primary-600'
                            : 'text-gray-500 group-hover:text-gray-600'
                        } mr-3 h-5 w-5`} 
                      />
                      Manage Elections
                    </Link>
                    
                    <Link
                      to="/admin/candidates"
                      className={`${
                        location.pathname === '/admin/candidates'
                          ? 'bg-primary-50 text-primary-700'
                          : 'text-gray-700 hover:bg-gray-50'
                      } group flex items-center px-2 py-2 text-sm font-medium rounded-md`}
                    >
                      <Award 
                        className={`${
                          location.pathname === '/admin/candidates'
                            ? 'text-primary-600'
                            : 'text-gray-500 group-hover:text-gray-600'
                        } mr-3 h-5 w-5`} 
                      />
                      Manage Candidates
                    </Link>
                    
                    <Link
                      to="/admin/students"
                      className={`${
                        location.pathname === '/admin/students'
                          ? 'bg-primary-50 text-primary-700'
                          : 'text-gray-700 hover:bg-gray-50'
                      } group flex items-center px-2 py-2 text-sm font-medium rounded-md`}
                    >
                      <Users 
                        className={`${
                          location.pathname === '/admin/students'
                            ? 'text-primary-600'
                            : 'text-gray-500 group-hover:text-gray-600'
                        } mr-3 h-5 w-5`} 
                      />
                      Manage Students
                    </Link>
                    
                    <Link
                      to="/admin/results"
                      className={`${
                        location.pathname === '/admin/results'
                          ? 'bg-primary-50 text-primary-700'
                          : 'text-gray-700 hover:bg-gray-50'
                      } group flex items-center px-2 py-2 text-sm font-medium rounded-md`}
                    >
                      <BarChart4 
                        className={`${
                          location.pathname === '/admin/results'
                            ? 'text-primary-600'
                            : 'text-gray-500 group-hover:text-gray-600'
                        } mr-3 h-5 w-5`} 
                      />
                      View Results
                    </Link>
                  </>
                ) : null}
              </nav>
            </div>
          </div>
        </div>
        
        {/* Main content */}
        <div className="md:pl-64 flex flex-col flex-1">
          <main className="flex-1">
            <div className="py-6">
              <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8">
                {children}
              </div>
            </div>
          </main>
        </div>
      </div>
    </div>
  );
};

export default DashboardLayout;