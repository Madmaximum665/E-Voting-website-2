import { useEffect } from 'react';
import { Routes, Route, useNavigate, useLocation } from 'react-router-dom';
import { useAuthStore } from './stores/authStore';

// Layouts
import AuthLayout from './layouts/AuthLayout';
import DashboardLayout from './layouts/DashboardLayout';

// Pages
import LoginPage from './pages/auth/LoginPage';
import StudentDashboard from './pages/student/StudentDashboard';
import ElectionDetails from './pages/student/ElectionDetails';
import VotePage from './pages/student/VotePage';
import ResultsPage from './pages/student/ResultsPage';
import AdminDashboard from './pages/admin/AdminDashboard';
import ManageElections from './pages/admin/ManageElections';
import CreateElection from './pages/admin/CreateElection';
import EditElection from './pages/admin/EditElection';
import ManageCandidates from './pages/admin/ManageCandidates';
import ManageStudents from './pages/admin/ManageStudents';
import AdminResults from './pages/admin/AdminResults';
import NotFoundPage from './pages/NotFoundPage';

// Initialize mock data
import './utils/initMockData';

function App() {
  const { user } = useAuthStore();
  const navigate = useNavigate();
  const location = useLocation();

  // Handle redirects based on authentication state
  useEffect(() => {
    if (!user) {
      // If not logged in and not already on login page, redirect to login
      if (!location.pathname.includes('/login')) {
        navigate('/login');
      }
    } else {
      // If logged in and on login page, redirect to appropriate dashboard
      if (location.pathname === '/login') {
        navigate(user.role === 'admin' ? '/admin' : '/dashboard');
      }
    }
  }, [user, navigate, location.pathname]);

  return (
    <Routes>
      {/* Auth routes */}
      <Route path="/login" element={<AuthLayout><LoginPage /></AuthLayout>} />
      
      {/* Student routes */}
      <Route path="/" element={<DashboardLayout><StudentDashboard /></DashboardLayout>} />
      <Route path="/dashboard" element={<DashboardLayout><StudentDashboard /></DashboardLayout>} />
      <Route path="/election/:id" element={<DashboardLayout><ElectionDetails /></DashboardLayout>} />
      <Route path="/vote/:id" element={<DashboardLayout><VotePage /></DashboardLayout>} />
      <Route path="/results/:id" element={<DashboardLayout><ResultsPage /></DashboardLayout>} />
      
      {/* Admin routes */}
      <Route path="/admin" element={<DashboardLayout><AdminDashboard /></DashboardLayout>} />
      <Route path="/admin/elections" element={<DashboardLayout><ManageElections /></DashboardLayout>} />
      <Route path="/admin/elections/create" element={<DashboardLayout><CreateElection /></DashboardLayout>} />
      <Route path="/admin/elections/edit/:id" element={<DashboardLayout><EditElection /></DashboardLayout>} />
      <Route path="/admin/candidates" element={<DashboardLayout><ManageCandidates /></DashboardLayout>} />
      <Route path="/admin/students" element={<DashboardLayout><ManageStudents /></DashboardLayout>} />
      <Route path="/admin/results" element={<DashboardLayout><AdminResults /></DashboardLayout>} />
      
      {/* 404 */}
      <Route path="*" element={<NotFoundPage />} />
    </Routes>
  );
}

export default App;